//
//  DetailActressViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 31/05/21.
//

import UIKit
import RxSwift
import RxRelay

class DetailActressViewController: UIViewController {
    
    private var selectedItem = BehaviorRelay(value: "Actress")
    var selectedVar : Observable<String> {
        
        return selectedItem.asObservable()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

    @IBAction func btnPick(_ sender: UIButton) {
        
        guard let charName = sender.titleLabel?.text else {return}
        
        selectedItem.accept(charName)
        
        navigationController?.popViewController(animated: true)
    }
    
   
}
