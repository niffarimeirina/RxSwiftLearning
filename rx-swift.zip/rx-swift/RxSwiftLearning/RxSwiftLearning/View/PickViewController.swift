//
//  PickViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 31/05/21.
//

import UIKit
import RxSwift
import RxRelay


class PickViewController: UIViewController {
    
  
    private var selectedCharacterVar = BehaviorRelay(value: "user") //subject
    
    var selectedChar : Observable<String> { //observable : untuk memberikan data (memancarkan sinyal)
        
        return selectedCharacterVar.asObservable() //pemancar sinyal = selectedCharacterVar.asObservable()
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    

    @IBAction func selectedBtn(_ sender: UIButton) {
        
        guard let charName = sender.titleLabel?.text else {return}
        
        selectedCharacterVar.accept(charName) //nilai selectedChar diubah ke charName
        
        navigationController?.popViewController(animated: true)
        
    }
    
    
  
    
}
