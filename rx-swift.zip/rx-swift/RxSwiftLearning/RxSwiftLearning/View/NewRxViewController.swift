//
//  NewRxViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 31/05/21.
//

import UIKit
import RxSwift
import RxCocoa

struct Product {

    let title : String
}

struct ProductViewModel {
    var items = PublishSubject<[Product]>()
    
    func fetchItems(){ //kalau fetch dri API, fungsi ini tinggal panggil API aja
        let products = [Product(title: "Pick Idol"), Product(title: "Pick Actress"), Product(title: "Pick Actor")
        ]
        
        
        items.onNext(products) //allow the observer get notified if the data has changed
        items.onCompleted()
    }
}

class NewRxViewController: UIViewController, UICollectionViewDelegate {
   
   

    @IBOutlet weak var collectionView: UICollectionView!
    
    private var viewModel = ProductViewModel()
    
    var bag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
        bindData()
   
    }
    
    
    @IBAction func profileClick(_ sender: UIBarButtonItem) {
        
        performSegue(withIdentifier: "profile", sender: self)
    }
    
    func bindData(){
        
        //bind item to collection item
        viewModel.items.bind(
            to: collectionView.rx.items(
                cellIdentifier: "cell",
                cellType: CollectionsViewCell.self)) { row, model, cell in
           
            cell.labelText.text = model.title
            cell.layer.cornerRadius = 8
            cell.layer.borderWidth = 0.5
            cell.layer.shadowRadius = 1.0
            
            
        }.disposed(by: bag)
        
        
        //bind a model selected handler
        Observable
            .zip(collectionView
                    .rx
                    .itemSelected,
                 collectionView
                    .rx
                    .modelSelected(Product.self)
            ).bind { (indexPath ,product) in
              
                if indexPath.item == 0 {
                    print(product.title)
                    let dahsboard = self.storyboard?.instantiateViewController(identifier: "dashboard") as! DashboardViewController
                    self.navigationController?.pushViewController(dahsboard, animated: true)
                }
                else if indexPath.item == 1 {
                    print(product.title)
                    let dahsboard = self.storyboard?.instantiateViewController(identifier: "actress") as! ActressViewController
                    self.navigationController?.pushViewController(dahsboard, animated: true)
                    
                }
                else {
                    print(product.title)
                    let dahsboard = self.storyboard?.instantiateViewController(identifier: "actor") as! ActorViewController
                    self.navigationController?.pushViewController(dahsboard, animated: true)
                }
                
            
            }.disposed(by: bag)

        
        //fetch items
        viewModel.fetchItems()
    }
    

}
