//
//  ActressViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 31/05/21.
//

import UIKit
import RxSwift
import RxCocoa

class ActressViewController: UIViewController {
    
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var userLabel: UILabel!
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        userLabel.isHidden = true
       
    }
    
    @IBAction func selectedItem(_ sender: UIBarButtonItem) {
        
        let pick = storyboard?.instantiateViewController(identifier: "detailActress") as! DetailActressViewController
        
        pick.selectedVar.subscribe(onNext: {[weak self] char in
            self?.userLabel.isHidden = false
            self?.label1.isHidden = true
            self?.userLabel.text = "You pick \(char)"
            
            
        }).disposed(by: disposeBag)
        
        navigationController?.pushViewController(pick, animated: true)
    }
    
   

}
