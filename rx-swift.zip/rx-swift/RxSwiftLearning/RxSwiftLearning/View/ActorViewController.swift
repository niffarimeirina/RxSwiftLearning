//
//  ActorViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 01/06/21.
//

import UIKit
import RxSwift
import RxCocoa

class ActorViewController: UIViewController {
    
    
    @IBOutlet weak var pickLabel: UILabel!
    
    @IBOutlet weak var userLabel: UILabel!
    
    
    let bag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        userLabel.isHidden = true
    }
    

    @IBAction func selectActor(_ sender: UIBarButtonItem) {
        
        let pick = storyboard?.instantiateViewController(identifier: "detailActor") as! DetailActorViewController
        
        pick.selectedVar.subscribe(onNext: { [weak self] char in
            self?.userLabel.isHidden = false
            self?.pickLabel.isHidden = true
            self?.userLabel.text = "You pick \(char)"
        }).disposed(by: bag)
        
        navigationController?.pushViewController(pick, animated: true)
    }
    
    
}
