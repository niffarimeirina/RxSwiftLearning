//
//  CollectionsViewCell.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 31/05/21.
//

import UIKit

class CollectionsViewCell: UICollectionViewCell {
    
    @IBOutlet weak var labelText: UILabel!
    
    @IBOutlet weak var labelName: UILabel!
    
    @IBOutlet weak var fieldName: UITextField!
    
}
