//
//  DashboardViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 31/05/21.
//

import UIKit
import RxSwift

class DashboardViewController: UIViewController {
   

    @IBOutlet weak var labelUser: UILabel!
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    
    @IBAction func selectChar(_ sender: UIBarButtonItem) {
        
        let pickVC = storyboard?.instantiateViewController(identifier: "pick") as! PickViewController
        pickVC.selectedChar.subscribe(onNext: {[weak self] char in
            
        self?.labelUser.text = "\(char)"
        }).disposed(by: disposeBag)
        
        navigationController?.pushViewController(pickVC, animated: true)
        
    }
    
    
    
  
    
}
