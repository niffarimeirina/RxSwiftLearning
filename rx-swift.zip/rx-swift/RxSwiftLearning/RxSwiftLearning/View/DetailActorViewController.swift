//
//  DetailActorViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 01/06/21.
//

import UIKit
import RxSwift
import RxRelay

class DetailActorViewController: UIViewController {
    
    private var selectedActor = BehaviorRelay<String>(value: "Actor")
    
    var selectedVar : Observable<String> {
        
        return selectedActor.asObservable()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
    
    @IBAction func pickActor(_ sender: UIButton) {
        
        guard let name = sender.titleLabel?.text else {return}
        selectedActor.accept(name)
        
        navigationController?.popViewController(animated: true)
        
    }
    
   

}
