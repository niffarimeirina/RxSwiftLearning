//
//  ProfileNewViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 02/06/21.
//

import UIKit
import RxSwift
import SwiftKeychainWrapper

class ProfileNewViewController: UIViewController, UICollectionViewDelegate {
    
    
  
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    let disposeBag = DisposeBag()
    var profileVM = ProfileViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
         bindData()
        
    }
    
    func bindData(){
        
        let result : Observable<[DetailUser]> = self.profileVM.apiProfile()
        _ = result.bind(to:collectionView.rx.items(cellIdentifier: "cell", cellType: CollectionsViewCell.self)) { row, model, cell in
            
            cell.fieldName.text = model.namaLengkap
            cell.layer.cornerRadius = 8
            cell.layer.borderWidth = 0.5
            cell.layer.shadowRadius = 1.0
            
        }.disposed(by: disposeBag)
        
    }

    @IBAction func logoutClick(_ sender: UIButton) {
        
        KeychainWrapper.standard.remove(forKey: "token")
        KeychainWrapper.standard.remove(forKey: "user")
        
        let vc = storyboard?.instantiateViewController(identifier: "login") as! LoginViewController
        
        navigationController?.pushViewController(vc, animated: true)
    }
    

}
