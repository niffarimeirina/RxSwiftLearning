//
//  LoginViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 02/06/21.
//

import UIKit
import RxSwift
import RxCocoa

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    var loginVM = LoginViewModel()
    let disposebag = DisposeBag()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loginVM.loginVC = self
        

        
        }
    


    @IBAction func loginClick(_ sender: UIButton) {
       
        loginVM.apiCalling().subscribe(onNext: { result in
           
            print("test")
            
            
        }).disposed(by: disposebag)
    }
    

}


