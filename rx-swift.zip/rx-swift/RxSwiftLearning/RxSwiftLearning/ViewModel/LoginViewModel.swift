//
//  LoginViewModel.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 02/06/21.
//

import Foundation
import RxSwift
import RxCocoa
import Alamofire
import SwiftKeychainWrapper


class LoginViewModel {
    
    var dataLogin : Login!
    var loginVC : LoginViewController?
    
    var items = PublishSubject<[Login]>()
    
    
    
    func apiCalling() -> Observable<Login> {
        
        return Observable<Login>.create { (observer) -> Disposable in
            
            var user = ""
            var password = ""
            
            user = self.loginVC?.emailField.text! ?? "nil"
            password = self.loginVC?.passwordField.text! ?? "nil"
            
            print(user)
            print(password)
            
            
            let credentialData = ("\(String(describing: user)):\(String(describing: password))").data(using: String.Encoding.utf8)!
            print(credentialData)
            
            let base64Credentials = credentialData.base64EncodedString(options: [])
            print(base64Credentials)
            
            let url: String = "https://bni-vaportal.com/authentication"
            
            var request = URLRequest(url:  NSURL(string: url)! as URL)
            request.httpMethod = "POST"
            request.setValue("Basic \(base64Credentials)", forHTTPHeaderField: "Authorization")
            
            AF.request(request)
                .responseString { (response) in
                    
                    guard let data = response.data else {return}
                    
                    
                    do {
                        
                        let dataLogin = try JSONDecoder().decode(Login.self, from: data)
                        
                        self.dataLogin = dataLogin
                        
                        observer.onNext(dataLogin) //allow observer to get notified it data has changed
                        observer.onCompleted()
                       
                        let _ = KeychainWrapper.standard.set(dataLogin.data, forKey: "token")
                      
                        let _ = KeychainWrapper.standard.set(user, forKey: "user")
                        
                        
                        DispatchQueue.main.async {
                            
                            let homePage = self.loginVC?.storyboard?.instantiateViewController(identifier: "new") as! NewRxViewController
                            self.loginVC?.navigationController?.pushViewController(homePage, animated: true)
                        }
                        
                        
                    }  catch{
                       
                        
                    }
       
                }
            return Disposables.create()
        
       

        }
       
    }

    
}
