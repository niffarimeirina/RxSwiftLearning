//
//  ProfileViewModel.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 02/06/21.
//

import Foundation
import RxSwift
import RxCocoa
import Alamofire
import SwiftKeychainWrapper


class ProfileViewModel {
    
    var dataProfile = [DetailUser]()
    var profile : ProfileNewViewController?
    

    
    func apiProfile() -> Observable<[DetailUser]> {
        
        return Observable<[DetailUser]>.create { (observer) -> Disposable in
            
            let url = "https://bni-vaportal.com/rest/api/userDetail"
            let token : String? = KeychainWrapper.standard.string(forKey: "token")
            let user : String? = KeychainWrapper.standard.string(forKey: "user")
            let headers: HTTPHeaders = ["Authorization" : "Bearer \(token!)"]
            
            let parameters : Parameters = [
                "username" : user!
            ]
            
            AF.request(url, method: .get, parameters: parameters, encoding: URLEncoding.default, headers: headers)
                
                .response { (responseData) in
                
                    guard let data = responseData.data else {return}
                    
                    
                    do{
                        let dataUser = try JSONDecoder().decode(UserDetail.self, from: data)
                        
                        if dataUser.ststusCode != "500" && dataUser.message != "Invalid Token" {
                            print("data user \(dataUser.data)")
                            print(responseData.result)
                            
                            
                            observer.onNext([dataUser.data])
                            observer.onCompleted()
                            
                        } else {print("error")}
                        
                    } catch{
                        print("Error decode \(error)")
                        
                    }
                    
                }
            return Disposables.create()
        }
        
    }
    
    
}
