//
//  Profile.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 01/06/21.
//

import Foundation


struct UserDetail : Decodable {
    let ststusCode : String
    let message : String
    let data : DetailUser
}

struct DetailUser : Decodable {
    let userId : String
    let namaLengkap : String
    let noTelepon : String
    let email : String
    let photo : String
    
}
