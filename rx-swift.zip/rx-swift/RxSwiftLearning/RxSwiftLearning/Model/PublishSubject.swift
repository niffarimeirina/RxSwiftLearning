//
//  PublishSubject.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 25/05/21.
//

import Foundation
import RxSwift

class PublishSubjectClass {
    
    var publishVC : ViewController?
    
    let disposeBag = DisposeBag()
    let publishSubject = PublishSubject<String>()
    
    
}
