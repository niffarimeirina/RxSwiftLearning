//
//  Login.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 02/06/21.
//

import Foundation

struct Login : Decodable {
    
    let ststusCode : String
    let message : String
    let data : String
}
