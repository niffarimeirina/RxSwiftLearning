//
//  BehaviorRelay.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 25/05/21.
//

import Foundation
import RxSwift
import RxCocoa


class BehaviorRelaySubject {
    
    var behaviorVC : ViewController?
    let disposeBag = DisposeBag()
    
    let behaviorRelay = BehaviorRelay<String>.init(value: "Initial value awal")
}
