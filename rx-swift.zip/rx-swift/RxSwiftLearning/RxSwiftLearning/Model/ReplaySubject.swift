//
//  ReplaySubject.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 25/05/21.
//

import Foundation
import RxSwift

class ReplaySubjectClass {
    
    var replayVC : ViewController?
    var disposeBag = DisposeBag()
    let replaySub = ReplaySubject<String>.create(bufferSize: 5)
    
    
}
