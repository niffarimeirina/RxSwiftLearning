//
//  BehaviorSubject.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 25/05/21.
//

import Foundation
import RxSwift

class BehaviorSubjectClass {
    
    var behaviorVC : ViewController?
    var disposeBag = DisposeBag()
    let behaviorSubject = BehaviorSubject<String>(value: "Inisialiasi Awal")
    
    
}
