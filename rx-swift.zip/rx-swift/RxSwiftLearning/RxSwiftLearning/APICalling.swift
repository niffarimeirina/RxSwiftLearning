//
//  APICalling.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 01/06/21.
//

import Foundation
import RxSwift
import RxCocoa


class APICalling {
    
    //create method for calling api which is return an observable
    
    func send<T: Decodable>(apiRequest: UserDetailClass) -> Observable<T> {
            return Observable<T>.create { observer in
                let request = apiRequest.apiProfile(with: apiRequest.baseURL!)
                let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                    do {
                        let model: UserDetail = try JSONDecoder().decode(UserDetail.self, from: data ?? Data())
                        observer.onNext( model.data as! T)
                        
                        print(model.data.namaLengkap)
                        
                    } catch let error {
                        observer.onError(error)
                    }
                    observer.onCompleted()
                }
                task.resume()
                
                return Disposables.create {
                    task.cancel()
                }
            }
        }
}
