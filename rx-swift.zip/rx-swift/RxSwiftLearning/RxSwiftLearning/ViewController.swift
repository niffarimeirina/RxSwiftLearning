//
//  ViewController.swift
//  RxSwiftLearning
//
//  Created by Niffari Meirina on 25/05/21.
//

import UIKit
import RxSwift

class ViewController: UIViewController {
    
    let publishSub = PublishSubjectClass()
    let behaviorSub = BehaviorSubjectClass()
    let replaySub = ReplaySubjectClass()
    let behaviorRelay = BehaviorRelaySubject()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        publishSub.publishVC = self
        behaviorSub.behaviorVC = self
        replaySub.replayVC = self
        behaviorRelay.behaviorVC = self
        
        let firstSubscription = publishSub.publishSubject.subscribe {
            print("first \($0)")
        
        }
        //isi value publishSubject
        publishSub.publishSubject.onNext("1")
        publishSub.publishSubject.onNext("2")
        
        let secondSubscription = publishSub.publishSubject.subscribe{
            print("second \($0)")
        }
        
        //isi value publishSubject
        publishSub.publishSubject.onNext("3")
        publishSub.publishSubject.onNext("4")
        
        //buang first subscription
        firstSubscription.disposed(by: publishSub.disposeBag)
        
        //isi value publishSubject
        publishSub.publishSubject.onNext("5")
        
        //buang second subscription
        secondSubscription.disposed(by: publishSub.disposeBag)
        
        print("\n")
        
        let firstSub = behaviorSub.behaviorSubject.subscribe {
            print("first behavior \($0)")
        }
        
        //isi value behaviorSubject
        behaviorSub.behaviorSubject.onNext("a")
        behaviorSub.behaviorSubject.onNext("b")
        
        let secondSub = behaviorSub.behaviorSubject.subscribe{
            print("second behavior \($0)")
        }
        
        //isi value behaviorSubject
        behaviorSub.behaviorSubject.onNext("c")
        behaviorSub.behaviorSubject.onNext("d")
        
        //buang first sub
        firstSub.disposed(by: behaviorSub.disposeBag)
        
        //isi value behaviorSubject
        behaviorSub.behaviorSubject.onNext("e")
        
        //buang second sub
        secondSub.disposed(by: behaviorSub.disposeBag)
        
        print("\n")
        
        let firstReplay = replaySub.replaySub.subscribe {
            print("first replay \($0)")
        }
        
        replaySub.replaySub.onNext("A")
        replaySub.replaySub.onNext("B")
        
        let secondReplay = replaySub.replaySub.subscribe{
            print("second replay \($0)")
        }
        
        replaySub.replaySub.onNext("C")
        replaySub.replaySub.onNext("D")
        
        let thirdReplay = replaySub.replaySub.subscribe{
            print("third replay \($0)")
        }
        
        //buang first sub
        firstReplay.disposed(by: replaySub.disposeBag)
        
        replaySub.replaySub.onNext("E")
        
        //buang second
        secondReplay.disposed(by: replaySub.disposeBag)
        
        //buang third
        thirdReplay.disposed(by: replaySub.disposeBag)
        
        print("\n")
        
        
        let firstRelay = behaviorRelay.behaviorRelay.subscribe{
            print("first behavior relay \($0)")
        }
        
        behaviorRelay.behaviorRelay.accept("Aa")
        behaviorRelay.behaviorRelay.accept("Bb")
        
        
        let secondRelay = behaviorRelay.behaviorRelay.subscribe {
            print("second behavior relay \($0)")
        }
        
        behaviorRelay.behaviorRelay.accept("Cc")
        behaviorRelay.behaviorRelay.accept("Dd")
        
        let thirdRelay = behaviorRelay.behaviorRelay.subscribe{
            print("third behavior relay \($0)")
        }
        
        firstRelay.disposed(by: behaviorRelay.disposeBag)
        
        behaviorRelay.behaviorRelay.accept("Ee")
        
        secondRelay.disposed(by: behaviorRelay.disposeBag)
        
        thirdRelay.disposed(by: behaviorRelay.disposeBag)
        
       
        
    }
    



}

